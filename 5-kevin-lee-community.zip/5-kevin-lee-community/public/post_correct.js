document.addEventListener("DOMContentLoaded", () => {
    const pathname = window.location.pathname;
    const postId = pathname.split('/').pop(); // 마지막 부분이 postId

    if (!postId) {
        console.error('No post ID found in the URL');
        return;
    }

    const postsContainer = document.getElementById('post_container');

    fetch(`http://localhost:4000/posts/${postId}`)
        .then(response => response.json())
        .then(response => {
            if (response.status === 200 && response.data) {
                const post = response.data;

                const postDiv = document.createElement('div');
                postDiv.classList.add('post');

                postDiv.innerHTML = `
                <form class="post_correct">
                    <div class="post_correct_title">제목*</div>
                    <hr class="horizontal-rule2"/>
                    <input value="${post.post_title}" maxlength="26" id="post_correct_titleInput"></input>
                    <hr class="horizontal-rule2"/>
                    <div id="post_correct_content">내용*</div>
                    <hr class="horizontal-rule2"/>
                    <textarea placeholder="내용 입력" id="post_correct_contentInput">${post.post_content}</textarea>
                    <hr class="horizontal-rule2"/>
                    <div class="post_correct_img_category">
                        <div class="post_correct_img_title">이미지</div>
                        <div class="post_correct_img_input_category">
                            <button id="post_correct_img_btn">파일 선택</button>
                            <p class="post_correct_img_txt">기존 파일 명</p>
                        </div>
                    </div>
                </form>`;

                postsContainer.appendChild(postDiv);

                const post_delete_modal = document.getElementById('postDelete_container');

                document.getElementById('backward').addEventListener('click', function(){
                    window.location.href = `/post/detail/${postId}`
                });
            
                document.getElementById('post_correct_btn').addEventListener('click', function(event){
                    event.preventDefault();

                    const postTitle = document.getElementById('post_correct_titleInput').value;
                    const postContent = document.getElementById('post_correct_contentInput').value;
                
                    console.log(postTitle, postContent);

                    fetch(`http://localhost:4000/posts/${postId}`, {
                        method: 'PATCH',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ postTitle, postContent })
                    })
                    .then(response => {
                        if (response.status != 200) {
                            throw new Error('게시글 수정에 실패했습니다.');
                        }
                        return response.json();
                    })
                    .then(data => {
                        alert('게시글이 수정되었습니다.');
                        window.location.href = `/post/detail/${postId}`;
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('게시글 수정 중 오류가 발생했습니다.');
                    });
                    
                });
                
            } else {
                console.error('Failed to fetch post details:', response);
            }
        })
        .catch(error => {
            console.error('Error fetching posts:', error);
        });
});


