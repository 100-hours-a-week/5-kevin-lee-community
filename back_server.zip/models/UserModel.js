const fs = require("fs");
const path = require("path");

class UserModel {
    constructor() {
        this.users = [];
        const userInfoPath = path.join(__dirname,"..", "data",'userInfo.json');
        const data = fs.readFileSync(userInfoPath, 'utf8');
        this.users = JSON.parse(data).users;
        
    }
    // 사용자 인증 메소드
    loginAuth(email, password) {
        if (!email) {
            return [400, "email"];
        } else if (!password) {
            return [400, "password"];
        }
        
        
        const user = this.users.find(user => user.email === email);
            

        if (user) {
            if (user.password === password) {
                return [200, "login_success", this.users];
            } else {
                return [401, "invalid_password"];
            }
        } else {
            return [401, "invalid_email"];
        }
    }

  signinAuth(email, password, nickname, img_file){
    if(!email){
        return [400, "invalid_email"];
    }else if(!password){
        return [400, invalid_password]
    }else if(!nickname){
        return [400, invalid_nickname]
    }

    const user = this.users.find(user => user.email === email);
    const nick = this.users.find(user => user.nickname === nickname);

    if(!user){
        if(!nick){
            //json에 등록
        }else{
            //return 닉네임 중복
        }
    }else{
        //return 이름 중복
    }

    //html과 js에 포커스 아웃될 때, 아이다와 닉네임은 중복 검사를 보내야 함.
  }
}

module.exports = UserModel;
